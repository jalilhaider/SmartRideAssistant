# ML Kit and Compose ship their own consumer rules; nothing extra is required.
